"""
Preprocessing pipeline construction.

Builds a scikit-learn ColumnTransformer that:
  - imputes + scales numerical columns (StandardScaler, needed for
    Logistic Regression; harmless for Random Forest)
  - imputes + one-hot encodes categorical columns

The transformer is always fit ONLY on the training split (inside the
sklearn Pipeline), never on the full dataset, to avoid data leakage.
"""
from __future__ import annotations

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Drop exact duplicate rows. Does not touch missing values (that is
    the job of the pipeline's imputers, applied post train/test split)."""
    return df.drop_duplicates().reset_index(drop=True)


def build_preprocessor(numerical_cols: list[str], categorical_cols: list[str]) -> ColumnTransformer:
    numeric_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])

    categorical_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])

    transformers = []
    if numerical_cols:
        transformers.append(("num", numeric_pipeline, numerical_cols))
    if categorical_cols:
        transformers.append(("cat", categorical_pipeline, categorical_cols))

    return ColumnTransformer(transformers=transformers, remainder="drop")


def get_output_feature_names(preprocessor: ColumnTransformer) -> list[str]:
    """
    Human-readable feature names after the ColumnTransformer, correctly
    expanding one-hot encoded categorical columns (e.g. "Gender_Male").
    """
    names: list[str] = []
    for name, transformer, cols in preprocessor.transformers_:
        if name == "remainder":
            continue
        if hasattr(transformer, "named_steps") and "onehot" in transformer.named_steps:
            ohe: OneHotEncoder = transformer.named_steps["onehot"]
            categories = ohe.categories_
            for col, cats in zip(cols, categories):
                for cat in cats:
                    names.append(f"{col}_{cat}")
        else:
            names.extend(cols)
    return names
