"""
Model training: builds full Pipeline(preprocessor + estimator) objects for
Logistic Regression and Random Forest, and fits them on a train split only.
"""
from __future__ import annotations

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

from .preprocessing import build_preprocessor

RANDOM_STATE = 42


class TooFewSamplesError(ValueError):
    pass


class SingleClassError(ValueError):
    pass


def split_data(df: pd.DataFrame, target_col: str, feature_cols: list[str], test_size: float = 0.2):
    if len(df) < 20:
        raise TooFewSamplesError(
            f"Dataset has only {len(df)} usable rows after cleaning; at least 20 are required to train."
        )

    y = df[target_col]
    if y.nunique(dropna=True) < 2:
        raise SingleClassError(
            f"Target column '{target_col}' has only one class; classification requires at least 2."
        )

    X = df[feature_cols]

    # Stratify when every class has enough members for the split; otherwise
    # fall back to a plain split rather than erroring out.
    stratify = y if y.value_counts().min() >= 2 else None

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=RANDOM_STATE, stratify=stratify
    )
    return X_train, X_test, y_train, y_test


def build_models(numerical_cols: list[str], categorical_cols: list[str]) -> dict[str, Pipeline]:
    """Returns {"logistic_regression": Pipeline, "random_forest": Pipeline}."""
    logistic_pipeline = Pipeline(steps=[
        ("preprocessor", build_preprocessor(numerical_cols, categorical_cols)),
        ("classifier", LogisticRegression(max_iter=1000, random_state=RANDOM_STATE)),
    ])

    rf_pipeline = Pipeline(steps=[
        ("preprocessor", build_preprocessor(numerical_cols, categorical_cols)),
        ("classifier", RandomForestClassifier(
            n_estimators=300,
            max_depth=None,
            min_samples_leaf=2,
            random_state=RANDOM_STATE,
            n_jobs=-1,
        )),
    ])

    return {"logistic_regression": logistic_pipeline, "random_forest": rf_pipeline}


def fit_models(models: dict[str, Pipeline], X_train, y_train) -> dict[str, Pipeline]:
    for pipeline in models.values():
        pipeline.fit(X_train, y_train)
    return models
