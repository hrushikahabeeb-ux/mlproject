"""
Prediction helpers: single-record and batch prediction using saved,
fully-fitted Pipeline objects (preprocessing + model bundled together via
joblib), so callers never need to manually encode/scale inputs.
"""
from __future__ import annotations

import pandas as pd
from sklearn.pipeline import Pipeline


def predict_single(pipeline: Pipeline, record: dict, feature_cols: list[str]) -> dict:
    row = {col: record.get(col) for col in feature_cols}
    X = pd.DataFrame([row], columns=feature_cols)

    prediction = pipeline.predict(X)[0]
    result = {"predicted_class": str(prediction)}

    if hasattr(pipeline, "predict_proba"):
        proba = pipeline.predict_proba(X)[0]
        classes = pipeline.classes_
        result["probabilities"] = {
            str(cls): float(p) for cls, p in zip(classes, proba)
        }
        result["confidence"] = float(max(proba))

    return result


def predict_batch(pipeline: Pipeline, df: pd.DataFrame, feature_cols: list[str]) -> pd.DataFrame:
    missing = [c for c in feature_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Uploaded CSV is missing required columns: {missing}")

    X = df[feature_cols]
    predictions = pipeline.predict(X)

    result_df = df.copy()
    result_df["Predicted_Class"] = predictions

    if hasattr(pipeline, "predict_proba"):
        proba = pipeline.predict_proba(X)
        classes = pipeline.classes_
        for i, cls in enumerate(classes):
            result_df[f"Probability_{cls}"] = proba[:, i]

    return result_df
