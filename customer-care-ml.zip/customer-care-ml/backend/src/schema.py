"""
Dataset schema detection.

Nothing here hard-codes column names. Every dataset that gets uploaded is
inspected at runtime: we detect likely ID columns (to drop), the target
column, and which remaining columns are numerical vs. categorical vs.
boolean. This keeps the whole pipeline dataset-agnostic.
"""
from __future__ import annotations

import pandas as pd

# Columns whose name strongly suggests they are an identifier, not a feature.
ID_NAME_HINTS = ("id", "customerid", "custid", "uuid", "index")

# Columns whose name strongly suggests they are the label we want to predict.
TARGET_NAME_HINTS = (
    "purchasestatus",
    "purchase_status",
    "target",
    "label",
    "class",
    "churn",
    "status",
    "outcome",
    "result",
)


def _looks_like_id(col: str, series: pd.Series, n_rows: int) -> bool:
    name = col.lower().replace("_", "").replace(" ", "")
    if any(hint in name for hint in ID_NAME_HINTS):
        return True
    # A column that is (almost) entirely unique integers behaves like an ID.
    if pd.api.types.is_integer_dtype(series) and series.nunique() >= 0.98 * n_rows and n_rows > 20:
        return True
    return False


def detect_id_columns(df: pd.DataFrame) -> list[str]:
    n = len(df)
    return [c for c in df.columns if _looks_like_id(c, df[c], n)]


def detect_target_column(df: pd.DataFrame, id_cols: list[str]) -> tuple[str | None, list[str]]:
    """
    Returns (best_guess_target, all_plausible_candidates).

    A plausible target is a non-ID column with a small number of distinct
    values relative to the dataset (i.e. it looks like a class label), or
    whose name strongly suggests it's a label/outcome.
    """
    n = len(df)
    candidates: list[str] = []

    for col in df.columns:
        if col in id_cols:
            continue
        series = df[col]
        nunique = series.nunique(dropna=True)
        name = col.lower().replace("_", "").replace(" ", "")

        name_match = any(hint in name for hint in TARGET_NAME_HINTS)
        # A "classification-shaped" column: small number of unique values,
        # not a near-continuous numeric spread.
        looks_categorical_target = nunique <= min(20, max(2, int(n * 0.05))) and nunique >= 2

        if name_match or looks_categorical_target:
            candidates.append(col)

    if not candidates:
        return None, []

    # Prefer a name match; among name matches, prefer fewer unique values
    # (binary/multiclass, not something accidentally categorical-looking).
    name_matches = [
        c for c in candidates
        if any(h in c.lower().replace("_", "").replace(" ", "") for h in TARGET_NAME_HINTS)
    ]
    ranked = sorted(name_matches or candidates, key=lambda c: df[c].nunique(dropna=True))
    best = ranked[0]
    return best, candidates


def classify_features(df: pd.DataFrame, target_col: str, id_cols: list[str]) -> dict:
    """
    Split remaining feature columns into numerical / categorical / boolean.
    """
    feature_cols = [c for c in df.columns if c != target_col and c not in id_cols]

    numerical, categorical, boolean = [], [], []
    for col in feature_cols:
        series = df[col]
        if pd.api.types.is_bool_dtype(series):
            boolean.append(col)
        elif pd.api.types.is_numeric_dtype(series):
            # Small-cardinality integer columns that look like flags (0/1)
            # are treated as boolean-ish categorical for form-rendering,
            # but numerically they're still fine to scale, so we keep them
            # in `numerical` for the ML pipeline. The API layer decides
            # the friendliest form-widget separately.
            numerical.append(col)
        else:
            categorical.append(col)

    return {
        "feature_cols": feature_cols,
        "numerical": numerical,
        "categorical": categorical,
        "boolean": boolean,
    }


def infer_schema(df: pd.DataFrame, target_override: str | None = None) -> dict:
    id_cols = detect_id_columns(df)
    if target_override:
        target_col = target_override
        candidates = [target_override]
    else:
        target_col, candidates = detect_target_column(df, id_cols)

    schema = {
        "id_cols": id_cols,
        "target_col": target_col,
        "target_candidates": candidates,
    }
    if target_col:
        schema.update(classify_features(df, target_col, id_cols))
    return schema
