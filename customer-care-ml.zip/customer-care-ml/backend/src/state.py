"""
Application state: orchestrates the full workflow (load CSV -> infer
schema -> clean -> split -> train -> evaluate -> save) and persists
everything needed to serve the API (schema, metrics, fitted pipelines)
both in-memory and on disk so it survives a server restart.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone

import joblib
import pandas as pd

from . import schema as schema_mod
from .evaluate import evaluate_pipeline, extract_feature_importance
from .predict import predict_batch, predict_single
from .preprocessing import clean_dataframe
from .train import (
    SingleClassError,
    TooFewSamplesError,
    build_models,
    fit_models,
    split_data,
)

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
MODELS_DIR = os.path.join(BASE_DIR, "models")
OUTPUTS_DIR = os.path.join(BASE_DIR, "outputs")
os.makedirs(OUTPUTS_DIR, exist_ok=True)

CURRENT_CSV_PATH = os.path.join(DATA_DIR, "current_dataset.csv")
SCHEMA_PATH = os.path.join(MODELS_DIR, "schema.json")
RESULTS_PATH = os.path.join(MODELS_DIR, "results.json")
LR_MODEL_PATH = os.path.join(MODELS_DIR, "logistic_regression.pkl")
RF_MODEL_PATH = os.path.join(MODELS_DIR, "random_forest.pkl")

MODEL_LABELS = {
    "logistic_regression": "Logistic Regression",
    "random_forest": "Random Forest",
}


class AppError(Exception):
    """Raised for user-facing, understandable error messages."""
    def __init__(self, message: str, status_code: int = 400):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


@dataclass
class AppState:
    raw_df: pd.DataFrame | None = None
    clean_df: pd.DataFrame | None = None
    filename: str | None = None
    schema: dict = field(default_factory=dict)
    pipelines: dict = field(default_factory=dict)
    results: dict = field(default_factory=dict)
    trained_at: str | None = None

    # ---- dataset ----
    def load_csv(self, path: str, filename: str, target_override: str | None = None):
        try:
            df = pd.read_csv(path)
        except Exception as exc:
            raise AppError(f"Could not read CSV file: {exc}") from exc

        if df.empty or df.shape[1] == 0:
            raise AppError("The uploaded CSV is empty or has no columns.")
        if len(df) < 20:
            raise AppError(
                f"The uploaded CSV only has {len(df)} rows; at least 20 are needed for training."
            )

        detected = schema_mod.infer_schema(df, target_override=target_override)
        if not detected["target_col"]:
            raise AppError(
                "Could not automatically identify a target column. "
                "Please specify which column should be predicted."
            )

        self.raw_df = df
        self.clean_df = clean_dataframe(df)
        self.filename = filename
        self.schema = detected
        # Any previous training is now stale.
        self.pipelines = {}
        self.results = {}
        self.trained_at = None

        os.makedirs(DATA_DIR, exist_ok=True)
        df.to_csv(CURRENT_CSV_PATH, index=False)
        with open(SCHEMA_PATH, "w") as f:
            json.dump(self.schema, f, indent=2)

        return self.dataset_summary()

    def require_dataset(self):
        if self.clean_df is None:
            raise AppError("No dataset has been uploaded yet. Please upload a CSV first.", 409)

    def require_trained(self):
        if not self.pipelines:
            raise AppError("Models have not been trained yet. Please train models first.", 409)

    def dataset_summary(self) -> dict:
        self.require_dataset()
        df = self.raw_df
        clean = self.clean_df
        target = self.schema["target_col"]

        missing = int(df.isnull().sum().sum())
        duplicates = int(df.duplicated().sum())
        class_dist = clean[target].value_counts().to_dict() if target in clean else {}

        return {
            "filename": self.filename,
            "n_rows": int(df.shape[0]),
            "n_rows_after_cleaning": int(clean.shape[0]),
            "n_columns": int(df.shape[1]),
            "target_column": target,
            "target_candidates": self.schema.get("target_candidates", []),
            "id_columns": self.schema.get("id_cols", []),
            "feature_columns": self.schema.get("feature_cols", []),
            "numerical_columns": self.schema.get("numerical", []),
            "categorical_columns": self.schema.get("categorical", []),
            "n_missing_values": missing,
            "n_duplicate_rows": duplicates,
            "n_classes": int(clean[target].nunique()) if target in clean else None,
            "class_distribution": {str(k): int(v) for k, v in class_dist.items()},
        }

    def column_info(self) -> list[dict]:
        self.require_dataset()
        df = self.raw_df
        info = []
        for col in df.columns:
            info.append({
                "column": col,
                "dtype": str(df[col].dtype),
                "missing_values": int(df[col].isnull().sum()),
                "unique_values": int(df[col].nunique(dropna=True)),
                "role": (
                    "target" if col == self.schema.get("target_col")
                    else "id" if col in self.schema.get("id_cols", [])
                    else "categorical" if col in self.schema.get("categorical", [])
                    else "numerical" if col in self.schema.get("numerical", [])
                    else "other"
                ),
            })
        return info

    def preview(self, n: int = 15) -> dict:
        self.require_dataset()
        preview_df = self.raw_df.head(n)
        return {
            "columns": list(preview_df.columns),
            "rows": preview_df.where(preview_df.notnull(), None).to_dict(orient="records"),
        }

    # ---- training ----
    def train(self) -> dict:
        self.require_dataset()
        target = self.schema["target_col"]
        feature_cols = self.schema["feature_cols"]
        numerical = self.schema["numerical"]
        categorical = self.schema["categorical"]

        try:
            X_train, X_test, y_train, y_test = split_data(self.clean_df, target, feature_cols)
        except (TooFewSamplesError, SingleClassError) as exc:
            raise AppError(str(exc)) from exc

        models = build_models(numerical, categorical)
        models = fit_models(models, X_train, y_train)

        results = {}
        for key, pipeline in models.items():
            metrics = evaluate_pipeline(pipeline, X_test, y_test)
            results[key] = {"label": MODEL_LABELS[key], **metrics}

        rf_importance = extract_feature_importance(models["random_forest"])
        results["random_forest"]["feature_importance"] = rf_importance

        self.pipelines = models
        self.results = results
        self.trained_at = datetime.now(timezone.utc).isoformat()

        os.makedirs(MODELS_DIR, exist_ok=True)
        joblib.dump(models["logistic_regression"], LR_MODEL_PATH)
        joblib.dump(models["random_forest"], RF_MODEL_PATH)
        with open(RESULTS_PATH, "w") as f:
            json.dump({"results": results, "trained_at": self.trained_at}, f, indent=2)

        return {"message": "Models trained successfully.", "trained_at": self.trained_at, "results": results}

    def get_results(self) -> dict:
        self.require_trained()
        return {"results": self.results, "trained_at": self.trained_at}

    def get_feature_importance(self) -> dict:
        self.require_trained()
        return {"feature_importance": self.results.get("random_forest", {}).get("feature_importance", [])}

    # ---- prediction ----
    def predict_one(self, model_key: str, record: dict) -> dict:
        self.require_trained()
        if model_key not in self.pipelines:
            raise AppError(f"Unknown model '{model_key}'. Choose 'logistic_regression' or 'random_forest'.")
        feature_cols = self.schema["feature_cols"]
        try:
            return predict_single(self.pipelines[model_key], record, feature_cols)
        except Exception as exc:
            raise AppError(f"Prediction failed: {exc}") from exc

    def predict_csv(self, model_key: str, df: pd.DataFrame) -> pd.DataFrame:
        self.require_trained()
        if model_key not in self.pipelines:
            raise AppError(f"Unknown model '{model_key}'. Choose 'logistic_regression' or 'random_forest'.")
        feature_cols = self.schema["feature_cols"]
        try:
            return predict_batch(self.pipelines[model_key], df, feature_cols)
        except ValueError as exc:
            raise AppError(str(exc)) from exc


state = AppState()
