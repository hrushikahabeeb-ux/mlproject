"""
Model evaluation: computes real metrics from actual predictions on the held
out test split. Nothing here is fabricated or hard-coded.
"""
from __future__ import annotations

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.pipeline import Pipeline

from .preprocessing import get_output_feature_names


def evaluate_pipeline(pipeline: Pipeline, X_test, y_test) -> dict:
    y_pred = pipeline.predict(X_test)
    labels = sorted(y_test.unique().tolist())

    average = "binary" if len(labels) == 2 else "macro"
    # For binary tasks, use the "positive" label as whichever sklearn would
    # infer by default (the larger of two labels, matching predict_proba's
    # class ordering) so displayed metrics line up with the confusion matrix.
    pos_label = labels[-1] if average == "binary" else None

    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average=average, pos_label=pos_label, zero_division=0)
    recall = recall_score(y_test, y_pred, average=average, pos_label=pos_label, zero_division=0)
    f1 = f1_score(y_test, y_pred, average=average, pos_label=pos_label, zero_division=0)

    cm = confusion_matrix(y_test, y_pred, labels=labels)
    report = classification_report(y_test, y_pred, labels=labels, output_dict=True, zero_division=0)

    return {
        "accuracy": float(accuracy),
        "precision": float(precision),
        "recall": float(recall),
        "f1_score": float(f1),
        "confusion_matrix": cm.tolist(),
        "labels": [str(l) for l in labels],
        "classification_report": report,
    }


def extract_feature_importance(pipeline: Pipeline, top_n: int = 15) -> list[dict]:
    """
    Extracts feature importance from a fitted Random Forest pipeline,
    correctly mapping one-hot expanded columns back to readable names.
    Returns [] for models without a feature_importances_ attribute
    (e.g. Logistic Regression is handled separately via coefficients if needed).
    """
    classifier = pipeline.named_steps.get("classifier")
    preprocessor = pipeline.named_steps.get("preprocessor")

    if classifier is None or not hasattr(classifier, "feature_importances_"):
        return []

    feature_names = get_output_feature_names(preprocessor)
    importances = classifier.feature_importances_

    if len(feature_names) != len(importances):
        # Defensive fallback in case of a mismatch; still don't fabricate,
        # just label generically.
        feature_names = [f"feature_{i}" for i in range(len(importances))]

    pairs = sorted(zip(feature_names, importances), key=lambda p: p[1], reverse=True)
    top = pairs[:top_n]
    return [{"feature": name, "importance": float(score)} for name, score in top]
