"""Standalone smoke test of the full ML pipeline against the real CSV."""
import sys
sys.path.insert(0, ".")

import pandas as pd
from src.schema import infer_schema
from src.preprocessing import clean_dataframe
from src.train import split_data, build_models, fit_models
from src.evaluate import evaluate_pipeline, extract_feature_importance
from src.predict import predict_single, predict_batch

df_raw = pd.read_csv("data/customer_purchase_data.csv")
print("Raw shape:", df_raw.shape)

df = clean_dataframe(df_raw)
print("After dedup:", df.shape)

schema = infer_schema(df)
print("Schema:", {k: v for k, v in schema.items() if k != "target_candidates"})

target = schema["target_col"]
feature_cols = schema["feature_cols"]
numerical = schema["numerical"]
categorical = schema["categorical"]

X_train, X_test, y_train, y_test = split_data(df, target, feature_cols)
print("Train/test sizes:", X_train.shape, X_test.shape)

models = build_models(numerical, categorical)
models = fit_models(models, X_train, y_train)
print("Trained:", list(models.keys()))

for name, pipeline in models.items():
    metrics = evaluate_pipeline(pipeline, X_test, y_test)
    print(f"\n{name} metrics:")
    print(" accuracy:", round(metrics["accuracy"], 4))
    print(" precision:", round(metrics["precision"], 4))
    print(" recall:", round(metrics["recall"], 4))
    print(" f1:", round(metrics["f1_score"], 4))
    print(" confusion_matrix:", metrics["confusion_matrix"])

rf_importance = extract_feature_importance(models["random_forest"])
print("\nTop RF feature importances:")
for item in rf_importance[:10]:
    print(" ", item["feature"], round(item["importance"], 4))

# single prediction smoke test
sample_record = X_test.iloc[0].to_dict()
single_result = predict_single(models["random_forest"], sample_record, feature_cols)
print("\nSingle prediction sample:", single_result)

# batch prediction smoke test
batch_result = predict_batch(models["logistic_regression"], X_test.head(5), feature_cols)
print("\nBatch prediction sample columns:", list(batch_result.columns))
print(batch_result[["Predicted_Class"] + [c for c in batch_result.columns if c.startswith("Probability")]].head())

print("\nALL OK")
