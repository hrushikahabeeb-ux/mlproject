"""
FastAPI backend for the Customer Care Prediction ML web app.

Endpoints:
  POST /api/upload              upload and inspect a CSV
  GET  /api/dataset/summary     dataset statistics
  GET  /api/dataset/preview     first N rows + column info
  GET  /api/analysis            EDA data (distributions, correlation)
  POST /api/train               train Logistic Regression + Random Forest
  GET  /api/results             evaluation metrics for both models
  GET  /api/feature-importance  Random Forest feature importance
  POST /api/predict             single-record prediction
  POST /api/predict/batch       batch prediction from an uploaded CSV
"""
from __future__ import annotations

import io
import os
import shutil

import numpy as np
import pandas as pd
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse

from src.state import AppError, DATA_DIR, OUTPUTS_DIR, state

app = FastAPI(title="Customer Care Prediction API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _clean_for_json(value):
    """Recursively replace NaN/inf with None so responses are valid JSON."""
    if isinstance(value, float):
        if np.isnan(value) or np.isinf(value):
            return None
        return value
    if isinstance(value, dict):
        return {k: _clean_for_json(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_clean_for_json(v) for v in value]
    return value


@app.exception_handler(AppError)
async def app_error_handler(request, exc: AppError):
    from fastapi.responses import JSONResponse
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.message})


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.post("/api/upload")
async def upload_csv(file: UploadFile = File(...), target_column: str | None = Form(None)):
    if not file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only .csv files are supported.")

    os.makedirs(DATA_DIR, exist_ok=True)
    dest_path = os.path.join(DATA_DIR, "uploaded_" + file.filename)
    with open(dest_path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    summary = state.load_csv(dest_path, file.filename, target_override=target_column)
    return _clean_for_json(summary)


@app.get("/api/dataset/summary")
def dataset_summary():
    return _clean_for_json(state.dataset_summary())


@app.get("/api/dataset/preview")
def dataset_preview(rows: int = 15):
    rows = max(1, min(rows, 20))
    result = state.preview(rows)
    column_info = state.column_info()
    return _clean_for_json({**result, "column_info": column_info})


@app.get("/api/analysis")
def analysis():
    state.require_dataset()
    df = state.clean_df
    target = state.schema["target_col"]
    numerical = state.schema["numerical"]
    categorical = state.schema["categorical"]

    target_distribution = {str(k): int(v) for k, v in df[target].value_counts().items()}

    numerical_stats = {}
    numerical_histograms = {}
    for col in numerical:
        series = df[col].dropna()
        if series.empty:
            continue
        numerical_stats[col] = {
            "mean": float(series.mean()),
            "median": float(series.median()),
            "std": float(series.std()),
            "min": float(series.min()),
            "max": float(series.max()),
        }
        counts, bin_edges = np.histogram(series, bins=10)
        numerical_histograms[col] = {
            "counts": counts.tolist(),
            "bin_edges": [round(float(e), 2) for e in bin_edges],
        }

    categorical_distributions = {}
    for col in categorical:
        vc = df[col].value_counts().head(12)
        categorical_distributions[col] = {str(k): int(v) for k, v in vc.items()}

    correlation = None
    if len(numerical) >= 2:
        corr_df = df[numerical].corr(numeric_only=True).round(3)
        correlation = {
            "columns": list(corr_df.columns),
            "matrix": corr_df.values.tolist(),
        }

    return _clean_for_json({
        "target_column": target,
        "target_distribution": target_distribution,
        "numerical_stats": numerical_stats,
        "numerical_histograms": numerical_histograms,
        "categorical_distributions": categorical_distributions,
        "correlation": correlation,
    })


@app.post("/api/train")
def train():
    result = state.train()
    return _clean_for_json(result)


@app.get("/api/results")
def results():
    return _clean_for_json(state.get_results())


@app.get("/api/feature-importance")
def feature_importance():
    return _clean_for_json(state.get_feature_importance())


@app.get("/api/schema")
def get_schema():
    """Feature schema used to render the prediction form on the frontend."""
    state.require_dataset()
    df = state.clean_df
    schema = state.schema
    fields = []
    for col in schema["feature_cols"]:
        if col in schema["categorical"]:
            options = sorted(df[col].dropna().unique().tolist())
            fields.append({"name": col, "type": "categorical", "options": [str(o) for o in options]})
        elif col in schema.get("boolean", []):
            fields.append({"name": col, "type": "boolean"})
        else:
            series = df[col].dropna()
            fields.append({
                "name": col,
                "type": "numerical",
                "min": float(series.min()) if not series.empty else 0,
                "max": float(series.max()) if not series.empty else 100,
                "default": float(series.median()) if not series.empty else 0,
            })
    return _clean_for_json({"fields": fields, "target_column": schema["target_col"]})


@app.post("/api/predict")
async def predict(payload: dict):
    model_key = payload.get("model")
    record = payload.get("record", {})
    if model_key not in ("logistic_regression", "random_forest"):
        raise HTTPException(status_code=400, detail="model must be 'logistic_regression' or 'random_forest'.")
    result = state.predict_one(model_key, record)
    return _clean_for_json(result)


@app.post("/api/predict/batch")
async def predict_batch_endpoint(file: UploadFile = File(...), model: str = Form("random_forest")):
    if model not in ("logistic_regression", "random_forest"):
        raise HTTPException(status_code=400, detail="model must be 'logistic_regression' or 'random_forest'.")
    if not file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only .csv files are supported.")

    contents = await file.read()
    try:
        df = pd.read_csv(io.BytesIO(contents))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not read CSV file: {exc}")

    if df.empty:
        raise HTTPException(status_code=400, detail="The uploaded CSV is empty.")

    result_df = state.predict_csv(model, df)

    output_path = os.path.join(OUTPUTS_DIR, "customer_predictions.csv")
    result_df.to_csv(output_path, index=False)

    preview_df = result_df.head(15)
    return _clean_for_json({
        "n_records": int(len(result_df)),
        "model_used": model,
        "columns": list(result_df.columns),
        "preview": preview_df.where(preview_df.notnull(), None).to_dict(orient="records"),
        "download_url": "/api/predict/batch/download",
    })


@app.get("/api/predict/batch/download")
def download_batch_predictions():
    output_path = os.path.join(OUTPUTS_DIR, "customer_predictions.csv")
    if not os.path.exists(output_path):
        raise HTTPException(status_code=404, detail="No batch predictions available yet. Run a batch prediction first.")

    def iterfile():
        with open(output_path, "rb") as f:
            yield from f

    return StreamingResponse(
        iterfile(),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=customer_predictions.csv"},
    )
