# Customer Care Prediction — ML Web Application

A full-stack machine learning web application that predicts customer purchase
behavior from an uploaded CSV dataset. Built as a college Machine Learning
project demonstrating the complete ML workflow: data inspection, preprocessing,
model training, evaluation, and prediction — all served through a FastAPI
backend and a React dashboard.

---

## 1. Project Overview

Customer care and retention teams need to anticipate customer behavior ahead
of time so they can target support and marketing effort effectively. This
application trains two classification models on historical customer data and
serves them through an interactive dashboard that lets you explore the
dataset, train models, compare their performance, and generate predictions
for new customers — one at a time or in bulk.

Every number displayed in the application (dataset statistics, accuracy,
precision, recall, F1-score, confusion matrices, feature importance, and
predictions) is computed directly from the uploaded CSV at runtime. Nothing
is hard-coded or fabricated.

## 2. Problem Statement

Given a dataset of customers with demographic, behavioral, and engagement
features, predict whether a customer will complete a purchase
(`PurchaseStatus`, the automatically detected target column for the included
sample dataset). The same application works with any similarly-shaped CSV:
the target column, feature types, and number of classes are all detected
automatically from whatever file is uploaded.

## 3. Dataset

The sample dataset (`backend/data/customer_purchase_data.csv`) contains 8,024
customer records with 18 columns:

| Column | Type | Description |
|---|---|---|
| CustomerID | Identifier | Dropped automatically before training |
| Age | Numerical | Customer age |
| Gender | Categorical | Female / Male |
| AnnualIncome | Numerical | Annual income (has some missing values) |
| SpendingScore | Numerical | Score reflecting spending behavior |
| PreviousPurchases | Numerical | Count of prior purchases |
| AverageOrderValue | Numerical | Average value per order |
| WebsiteVisits | Numerical | Number of website visits |
| TimeSpentOnWebsite | Numerical | Minutes spent on site (has missing values) |
| CartAdditions | Numerical | Items added to cart |
| DiscountsUsed | Numerical | Number of discounts used |
| EmailEngagement | Numerical | Engagement score (has missing values) |
| CustomerSupportInteractions | Numerical | Support interaction count |
| MembershipYears | Numerical | Years as a member |
| DaysSinceLastPurchase | Numerical | Recency of last purchase |
| PreferredDevice | Categorical | Desktop / Mobile / Tablet |
| ProductCategory | Categorical | One of 7 product categories |
| **PurchaseStatus** | **Target (binary)** | 0 = did not purchase, 1 = purchased |

The dataset is close to balanced (≈50.4% / 49.6%), contains 244 missing
values across three numerical columns, and 24 duplicate rows — all handled
automatically by the preprocessing pipeline.

## 4. Features & Target

- **Features used for training:** all columns except `CustomerID` (identifier)
  and `PurchaseStatus` (target) — 16 features total (13 numerical, 3
  categorical).
- **Target:** `PurchaseStatus`, auto-detected because it is the only
  low-cardinality, non-ID column whose name matches common target-name
  patterns (`status`, `target`, `class`, etc.).
- If you upload a different CSV where the target is ambiguous, the `/api/upload`
  endpoint accepts an optional `target_column` override.

## 5. ML Algorithms

**Logistic Regression** — a linear model estimating class probability via a
sigmoid function over a weighted sum of features. Fast, interpretable, and
effective when the relationship between features and outcome is close to
linear.

**Random Forest Classifier** — an ensemble of decision trees trained on
random subsets of data and features, combined via majority vote. Captures
non-linear patterns and feature interactions, at some cost to direct
interpretability (mitigated here with feature importance).

Both models use `random_state=42` for reproducibility.

## 6. Preprocessing

Implemented in `backend/src/preprocessing.py` and `backend/src/train.py`,
using scikit-learn's `ColumnTransformer` and `Pipeline`:

- **Numerical columns:** median imputation → `StandardScaler`
- **Categorical columns:** most-frequent imputation → `OneHotEncoder`
  (`handle_unknown="ignore"`)
- Exact duplicate rows are dropped before splitting.
- **No data leakage:** the preprocessing pipeline is fit only on the training
  split (inside the same `Pipeline` object as the classifier), never on the
  full dataset or the test split.
- An 80/20 stratified train/test split is used (`random_state=42`).

## 7. Evaluation

Both models are evaluated on the held-out test set using:

- Accuracy, Precision, Recall, F1-score (binary or macro-averaged depending
  on the number of classes)
- Confusion matrix
- Full classification report (per-class + macro/weighted averages)
- Random Forest feature importance (`feature_importances_`, correctly mapped
  back through one-hot encoded columns to their original feature names)

## 8. Technologies

**Backend:** Python, FastAPI, Pandas, NumPy, Scikit-learn, Joblib
**Frontend:** React, Vite, Tailwind CSS, Recharts, Axios

## 9. Project Structure

```text
customer-care-ml/
│
├── backend/
│   ├── main.py                  # FastAPI app and all endpoints
│   ├── requirements.txt
│   ├── test_pipeline.py         # standalone smoke test of the ML pipeline
│   │
│   ├── src/
│   │   ├── schema.py            # dataset-agnostic column/target detection
│   │   ├── preprocessing.py     # ColumnTransformer construction
│   │   ├── train.py             # train/test split + model building
│   │   ├── evaluate.py          # metrics + feature importance
│   │   ├── predict.py           # single & batch prediction helpers
│   │   └── state.py             # in-memory app state / orchestration
│   │
│   ├── models/                  # saved .pkl pipelines + schema/results JSON
│   ├── data/                    # uploaded datasets
│   └── outputs/                 # generated batch prediction CSVs
│
├── frontend/
│   ├── package.json
│   ├── src/
│   │   ├── components/          # Layout, UI primitives, charts
│   │   ├── pages/                # the 9 pages
│   │   ├── services/api.js       # API client
│   │   ├── context/AppContext.jsx
│   │   ├── App.jsx
│   │   └── main.jsx
│   └── ...
│
├── README.md
└── .gitignore
```

## 10. Installation

### Prerequisites
- Python 3.10+
- Node.js 18+

### Backend setup

```bash
cd backend
pip install -r requirements.txt
```

### Frontend setup

```bash
cd frontend
npm install
```

## 11. Running the Application

### Start the backend (from `backend/`)

```bash
python3 -m uvicorn main:app --host 0.0.0.0 --port 8000
```

The API will be available at `http://localhost:8000`, with interactive docs
at `http://localhost:8000/docs`.

### Start the frontend (from `frontend/`)

```bash
npm run dev -- --host 0.0.0.0 --port 5173
```

The app will be available at `http://localhost:5173`. The Vite dev server
proxies `/api/*` requests to the backend automatically (see
`frontend/vite.config.js`).

## 12. Using the Application

1. **Dataset** — upload your CSV (or the included
   `backend/data/customer_purchase_data.csv`). The app inspects it and shows
   row/column counts, the detected target column, missing values, duplicates,
   a preview table, and column-level information.
2. **Analysis** — explore the target class distribution, numerical feature
   histograms, categorical distributions, and a correlation heatmap.
3. **Training** — click **🚀 Train Models** to preprocess the data, split it,
   train both Logistic Regression and Random Forest, and evaluate them.
4. **Comparison** — see a side-by-side metrics table and bar chart comparing
   both models.
5. **Models** — inspect detailed per-model evaluation (classification report,
   confusion matrix) and Random Forest feature importance.
6. **Prediction** — fill in a form (auto-generated from your dataset's
   feature columns) to predict a single customer's outcome, with class
   probabilities.
7. **Batch Prediction** — upload a new CSV of customers (without the target
   column) to generate predictions for all of them at once, previewed in the
   browser and downloadable as `customer_predictions.csv`.
8. **About** — a viva-friendly explanation of the problem, objective, ML
   workflow, algorithms, and evaluation metrics.

## 13. API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/upload` | Upload and inspect a CSV (optional `target_column` override) |
| GET | `/api/dataset/summary` | Dataset statistics |
| GET | `/api/dataset/preview` | Preview rows + column info |
| GET | `/api/analysis` | EDA data (distributions, correlation) |
| POST | `/api/train` | Train both models and evaluate |
| GET | `/api/results` | Evaluation metrics for both models |
| GET | `/api/feature-importance` | Random Forest feature importance |
| GET | `/api/schema` | Feature schema used to render the prediction form |
| POST | `/api/predict` | Single-record prediction |
| POST | `/api/predict/batch` | Batch prediction from an uploaded CSV |
| GET | `/api/predict/batch/download` | Download the last batch prediction results |

All endpoints return clean JSON and understandable error messages (e.g. for
an empty CSV, a single-class target, missing prediction columns, or
predicting before training).

## 14. Project Structure Notes / Future Scope

- The current implementation keeps trained models and dataset state in
  server memory plus on-disk `.pkl`/`.json` files in `backend/models/`, so
  state survives a backend restart as long as those files remain.
- Future improvements could include: hyperparameter tuning (e.g. grid search
  for Random Forest depth/estimators), support for additional algorithms
  (e.g. Gradient Boosting), persistent multi-user storage (a real database
  instead of a single shared app state), authentication, and deployment
  configuration (Docker, CI/CD).

## 15. Reproducibility

All train/test splits and model training use `random_state=42`, so
re-training on the same dataset produces the same split and (for Random
Forest) the same trees, ensuring consistent, reproducible results.
