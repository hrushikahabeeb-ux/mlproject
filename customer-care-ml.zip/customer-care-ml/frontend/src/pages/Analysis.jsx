import { useEffect, useState } from "react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card, EmptyState, ErrorBanner, LoadingSpinner, PageHeader } from "../components/UI";
import Heatmap from "../components/Heatmap";
import { useAppContext } from "../context/AppContext";
import { getAnalysis } from "../services/api";

const BAR_COLOR = "#3568f5";
const BAR_COLOR_2 = "#5b93ff";

export default function Analysis() {
  const { datasetLoaded, refreshStatus } = useAppContext();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    refreshStatus().then(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (datasetLoaded) {
      setLoading(true);
      getAnalysis()
        .then(setData)
        .catch((e) => setError(e.message))
        .finally(() => setLoading(false));
    }
  }, [datasetLoaded]);

  if (loading) return <LoadingSpinner label="Loading analysis..." />;

  if (!datasetLoaded) {
    return (
      <div>
        <PageHeader title="Data Analysis" subtitle="Exploratory data analysis of your dataset" />
        <EmptyState icon="🔍" title="No dataset loaded" description="Upload a CSV on the Dataset page first." />
      </div>
    );
  }

  if (error) {
    return (
      <div>
        <PageHeader title="Data Analysis" />
        <ErrorBanner message={error} />
      </div>
    );
  }

  if (!data) {
    return <LoadingSpinner label="Loading analysis..." />;
  }

  const targetData = Object.entries(data.target_distribution).map(([name, value]) => ({ name, value }));

  return (
    <div>
      <PageHeader title="Data Analysis" subtitle="Exploratory data analysis of your dataset" />

      <Card className="mb-6">
        <h2 className="mb-1 text-sm font-semibold text-slate-800">Target Distribution — {data.target_column}</h2>
        <p className="mb-4 text-xs text-slate-500">
          The target distribution shows how many observations belong to each customer-care class.
        </p>
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={targetData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#eef1f6" />
            <XAxis dataKey="name" tick={{ fontSize: 12 }} />
            <YAxis tick={{ fontSize: 12 }} />
            <Tooltip />
            <Bar dataKey="value" fill={BAR_COLOR} radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      <Card className="mb-6">
        <h2 className="mb-1 text-sm font-semibold text-slate-800">Numerical Feature Distributions</h2>
        <p className="mb-4 text-xs text-slate-500">
          Histograms of key numerical features, binned into 10 equal-width buckets.
        </p>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          {Object.entries(data.numerical_histograms)
            .slice(0, 6)
            .map(([col, hist]) => {
              const chartData = hist.counts.map((count, i) => ({
                bucket: `${hist.bin_edges[i]}–${hist.bin_edges[i + 1]}`,
                count,
              }));
              return (
                <div key={col}>
                  <p className="mb-2 text-xs font-semibold text-slate-600">{col}</p>
                  <ResponsiveContainer width="100%" height={160}>
                    <BarChart data={chartData}>
                      <XAxis dataKey="bucket" tick={{ fontSize: 9 }} interval={1} />
                      <YAxis tick={{ fontSize: 9 }} width={28} />
                      <Tooltip />
                      <Bar dataKey="count" fill={BAR_COLOR_2} radius={[3, 3, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              );
            })}
        </div>
      </Card>

      {Object.keys(data.categorical_distributions).length > 0 && (
        <Card className="mb-6">
          <h2 className="mb-1 text-sm font-semibold text-slate-800">Categorical Feature Distributions</h2>
          <p className="mb-4 text-xs text-slate-500">Category counts for each categorical column.</p>
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            {Object.entries(data.categorical_distributions).map(([col, dist]) => {
              const chartData = Object.entries(dist).map(([name, value]) => ({ name, value }));
              return (
                <div key={col}>
                  <p className="mb-2 text-xs font-semibold text-slate-600">{col}</p>
                  <ResponsiveContainer width="100%" height={180}>
                    <BarChart data={chartData} layout="vertical" margin={{ left: 20 }}>
                      <XAxis type="number" tick={{ fontSize: 10 }} />
                      <YAxis type="category" dataKey="name" tick={{ fontSize: 10 }} width={90} />
                      <Tooltip />
                      <Bar dataKey="value" fill={BAR_COLOR} radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {data.correlation && (
        <Card>
          <h2 className="mb-1 text-sm font-semibold text-slate-800">Correlation Heatmap</h2>
          <p className="mb-4 text-xs text-slate-500">
            Pearson correlation between numerical features. Values closer to 1 or -1 indicate a
            stronger linear relationship; values near 0 indicate little linear relationship.
          </p>
          <Heatmap columns={data.correlation.columns} matrix={data.correlation.matrix} />
        </Card>
      )}
    </div>
  );
}
