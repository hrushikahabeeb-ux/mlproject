import { Card, PageHeader, WorkflowDiagram } from "../components/UI";
import { useAppContext } from "../context/AppContext";

const TECHNOLOGIES = ["Python", "Pandas", "Scikit-learn", "FastAPI", "React", "Tailwind CSS"];

export default function About() {
  const { datasetSummary } = useAppContext();
  const targetLabel = datasetSummary?.target_column || "the target outcome";

  return (
    <div>
      <PageHeader title="About & ML Workflow" subtitle="Project overview for viva / presentation" />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card>
            <h2 className="mb-2 text-sm font-semibold text-slate-800">Problem Statement</h2>
            <p className="text-sm leading-relaxed text-slate-600">
              Customer care and retention teams need to know, ahead of time, which customers are
              likely to behave in a particular way — in this project, whether a customer will reach{" "}
              <strong>{targetLabel}</strong> — so that support and marketing effort can be targeted
              where it matters most. Given historical customer data (demographics, browsing behavior,
              purchase history, and engagement metrics), this application builds a machine learning
              system that predicts that outcome for new or existing customers.
            </p>
          </Card>

          <Card>
            <h2 className="mb-2 text-sm font-semibold text-slate-800">Objective</h2>
            <p className="text-sm leading-relaxed text-slate-600">
              The objective is to train and compare two classification models —{" "}
              <strong>Logistic Regression</strong> and <strong>Random Forest</strong> — that learn
              patterns from labeled historical data and generalize those patterns to predict{" "}
              <strong>{targetLabel}</strong> for customers the model has not seen before. The system
              is evaluated using accuracy, precision, recall, and F1-score, and supports both
              single-customer and batch predictions.
            </p>
          </Card>

          <Card>
            <h2 className="mb-2 text-sm font-semibold text-slate-800">Logistic Regression</h2>
            <p className="text-sm leading-relaxed text-slate-600">
              Logistic Regression is a linear model that estimates the probability of each class by
              fitting a weighted combination of the input features and passing it through a sigmoid
              (or softmax, for more than two classes) function. It is fast to train, easy to
              interpret — each feature gets a coefficient describing its effect on the outcome — and
              works well when the relationship between features and the target is roughly linear.
            </p>
          </Card>

          <Card>
            <h2 className="mb-2 text-sm font-semibold text-slate-800">Random Forest</h2>
            <p className="text-sm leading-relaxed text-slate-600">
              Random Forest is an ensemble method that builds many decision trees, each trained on a
              random subset of the data and features, and combines their predictions by majority
              vote. This makes it more robust to noise and better able to capture non-linear
              relationships and feature interactions than a single model, at the cost of being
              somewhat less directly interpretable than Logistic Regression (though feature
              importance, shown on the Models page, offers a window into what it learned).
            </p>
          </Card>

          <Card>
            <h2 className="mb-3 text-sm font-semibold text-slate-800">Evaluation Metrics</h2>
            <dl className="space-y-3 text-sm text-slate-600">
              <div>
                <dt className="font-semibold text-slate-800">Accuracy</dt>
                <dd>The proportion of all predictions that were correct.</dd>
              </div>
              <div>
                <dt className="font-semibold text-slate-800">Precision</dt>
                <dd>Of all the cases predicted positive, the fraction that were actually positive.</dd>
              </div>
              <div>
                <dt className="font-semibold text-slate-800">Recall</dt>
                <dd>Of all the cases that were actually positive, the fraction the model correctly identified.</dd>
              </div>
              <div>
                <dt className="font-semibold text-slate-800">F1-Score</dt>
                <dd>The harmonic mean of precision and recall — a single number that balances both.</dd>
              </div>
              <div>
                <dt className="font-semibold text-slate-800">Confusion Matrix</dt>
                <dd>A table showing correct and incorrect predictions broken down by actual vs. predicted class.</dd>
              </div>
            </dl>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <h2 className="mb-4 text-center text-sm font-semibold text-slate-800">Machine Learning Workflow</h2>
            <WorkflowDiagram
              steps={[
                "Dataset",
                "Data Cleaning",
                "Feature Engineering / Encoding",
                "Train/Test Split",
                "Logistic Regression",
                "Random Forest",
                "Evaluation",
                "Prediction",
              ]}
            />
          </Card>

          <Card>
            <h2 className="mb-3 text-sm font-semibold text-slate-800">Technologies</h2>
            <div className="flex flex-wrap gap-2">
              {TECHNOLOGIES.map((t) => (
                <span key={t} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-700">
                  {t}
                </span>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
