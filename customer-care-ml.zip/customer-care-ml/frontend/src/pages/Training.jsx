import { useEffect, useState } from "react";
import { Button, Card, EmptyState, ErrorBanner, PageHeader, SuccessBanner } from "../components/UI";
import { useAppContext } from "../context/AppContext";
import { trainModels } from "../services/api";

export default function Training() {
  const { datasetLoaded, refreshStatus, results, setResults, setModelsTrained, trainedAt, setTrainedAt } = useAppContext();
  const [training, setTraining] = useState(false);
  const [error, setError] = useState("");
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    refreshStatus().finally(() => setChecking(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleTrain = async () => {
    setTraining(true);
    setError("");
    try {
      const res = await trainModels();
      setResults(res.results);
      setTrainedAt(res.trained_at);
      setModelsTrained(true);
    } catch (e) {
      setError(e.message);
    } finally {
      setTraining(false);
    }
  };

  if (checking) return null;

  if (!datasetLoaded) {
    return (
      <div>
        <PageHeader title="Model Training" subtitle="Train Logistic Regression and Random Forest models" />
        <EmptyState icon="🚀" title="No dataset loaded" description="Upload a CSV on the Dataset page before training models." />
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Model Training" subtitle="Train Logistic Regression and Random Forest models" />
      <ErrorBanner message={error} />
      {results && !training && <SuccessBanner message={`Training complete${trainedAt ? ` at ${new Date(trainedAt).toLocaleString()}` : ""}. See the Comparison and Models pages for results.`} />}

      <Card className="mb-6">
        <h2 className="mb-4 text-center text-sm font-semibold text-slate-800">Training Pipeline</h2>
        <div className="flex flex-col items-center gap-1">
          <Step label="Dataset" />
          <Arrow />
          <Step label="Preprocessing" />
          <Arrow />
          <Step label="Train/Test Split" />
          <Arrow />
          <div className="flex items-center gap-8">
            <div className="flex flex-col items-center gap-1">
              <Arrow flip />
              <Step label="Logistic Regression" tone="blue" />
            </div>
            <div className="flex flex-col items-center gap-1">
              <Arrow flip />
              <Step label="Random Forest" tone="amber" />
            </div>
          </div>
          <Arrow />
          <Step label="Evaluation" tone="green" />
        </div>
      </Card>

      <Card className="flex flex-col items-center gap-4 py-10 text-center">
        <p className="max-w-md text-sm text-slate-600">
          Clicking the button below preprocesses your cleaned dataset, performs an 80/20 train/test
          split (random_state=42), trains both models, evaluates them on the held-out test set, and
          saves the resulting pipelines.
        </p>
        <Button onClick={handleTrain} disabled={training} className="px-6 py-3 text-base">
          {training ? (
            <>
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
              Training models...
            </>
          ) : (
            "🚀 Train Models"
          )}
        </Button>
      </Card>
    </div>
  );
}

function Step({ label, tone = "brand" }) {
  const tones = {
    brand: "border-brand-200 bg-brand-50 text-brand-700",
    blue: "border-blue-200 bg-blue-50 text-blue-700",
    amber: "border-amber-200 bg-amber-50 text-amber-700",
    green: "border-emerald-200 bg-emerald-50 text-emerald-700",
  };
  return (
    <div className={`rounded-lg border px-4 py-2 text-sm font-medium ${tones[tone]}`}>{label}</div>
  );
}

function Arrow({ flip }) {
  return <span className="text-slate-300">{flip ? "↑" : "↓"}</span>;
}
