import { useCallback, useEffect, useState } from "react";
import { Badge, Button, Card, ErrorBanner, LoadingSpinner, PageHeader, StatCard, Table } from "../components/UI";
import { useAppContext } from "../context/AppContext";
import { getDatasetPreview, uploadDataset } from "../services/api";

export default function Dataset() {
  const { datasetSummary, setDatasetSummary, datasetLoaded, setDatasetLoaded, refreshStatus, setModelsTrained } = useAppContext();
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [preview, setPreview] = useState(null);
  const [previewLoading, setPreviewLoading] = useState(false);

  useEffect(() => {
    refreshStatus();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (datasetLoaded) {
      setPreviewLoading(true);
      getDatasetPreview(15)
        .then(setPreview)
        .catch((e) => setError(e.message))
        .finally(() => setPreviewLoading(false));
    }
  }, [datasetLoaded]);

  const handleFile = useCallback(
    async (file) => {
      if (!file) return;
      if (!file.name.toLowerCase().endsWith(".csv")) {
        setError("Please upload a .csv file.");
        return;
      }
      setError("");
      setUploading(true);
      try {
        const summary = await uploadDataset(file);
        setDatasetSummary(summary);
        setDatasetLoaded(true);
        setModelsTrained(false); // uploading a new dataset invalidates prior training
        setPreviewLoading(true);
        const p = await getDatasetPreview(15);
        setPreview(p);
      } catch (e) {
        setError(e.message);
      } finally {
        setUploading(false);
        setPreviewLoading(false);
      }
    },
    [setDatasetSummary, setDatasetLoaded, setModelsTrained]
  );

  return (
    <div>
      <PageHeader title="Dataset" subtitle="Upload and explore your customer CSV data" />
      <ErrorBanner message={error} />

      <Card
        className={`mb-6 flex flex-col items-center justify-center gap-2 border-2 border-dashed py-12 text-center transition-colors ${
          dragOver ? "border-brand-500 bg-brand-50" : "border-slate-300"
        }`}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          handleFile(e.dataTransfer.files?.[0]);
        }}
      >
        <span className="text-4xl">📤</span>
        <p className="text-base font-semibold text-slate-800">Upload Customer CSV</p>
        <p className="text-sm text-slate-500">Drag & drop your file here, or click browse</p>
        <label>
          <input
            type="file"
            accept=".csv"
            className="hidden"
            onChange={(e) => handleFile(e.target.files?.[0])}
          />
          <span className="mt-2 inline-block cursor-pointer rounded-lg bg-brand-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-brand-700">
            {uploading ? "Uploading..." : "Browse Files"}
          </span>
        </label>
      </Card>

      {!datasetLoaded && !uploading && (
        <p className="text-center text-sm text-slate-400">No dataset uploaded yet.</p>
      )}

      {datasetLoaded && datasetSummary && (
        <>
          <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            <StatCard label="File Name" value={<span className="text-sm font-semibold break-all">{datasetSummary.filename}</span>} />
            <StatCard label="Rows" value={datasetSummary.n_rows.toLocaleString()} hint={`${datasetSummary.n_rows_after_cleaning} after cleaning`} />
            <StatCard label="Columns" value={datasetSummary.n_columns} />
            <StatCard label="Target Column" value={<span className="text-lg">{datasetSummary.target_column}</span>} />
            <StatCard label="Missing Values" value={datasetSummary.n_missing_values} accent={datasetSummary.n_missing_values > 0 ? "amber" : "green"} />
            <StatCard label="Duplicate Rows" value={datasetSummary.n_duplicate_rows} accent={datasetSummary.n_duplicate_rows > 0 ? "amber" : "green"} />
          </div>

          {previewLoading && <LoadingSpinner label="Loading preview..." />}

          {preview && !previewLoading && (
            <>
              <Card className="mb-6">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-sm font-semibold text-slate-800">Dataset Preview</h2>
                  <Badge color="blue">First {preview.rows.length} rows</Badge>
                </div>
                <Table columns={preview.columns} rows={preview.rows} />
              </Card>

              <Card>
                <h2 className="mb-3 text-sm font-semibold text-slate-800">Column Information</h2>
                <Table
                  columns={["column", "dtype", "role", "missing_values", "unique_values"]}
                  rows={preview.column_info.map((c) => ({
                    column: c.column,
                    dtype: c.dtype,
                    role: c.role,
                    missing_values: c.missing_values,
                    unique_values: c.unique_values,
                  }))}
                />
              </Card>
            </>
          )}
        </>
      )}
    </div>
  );
}
