import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Card, PageHeader, StatCard, WorkflowDiagram, Button, EmptyState, LoadingSpinner } from "../components/UI";
import { useAppContext } from "../context/AppContext";

const WORKFLOW_STEPS = [
  "CSV Dataset",
  "Data Preprocessing",
  "Train/Test Split",
  "ML Models",
  "Evaluation",
  "Prediction",
];

export default function Dashboard() {
  const { datasetSummary, results, datasetLoaded, modelsTrained, refreshStatus } = useAppContext();
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    refreshStatus().finally(() => setChecking(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (checking) return <LoadingSpinner label="Checking dataset and model status..." />;

  if (!datasetLoaded) {
    return (
      <div>
        <PageHeader title="Customer Care Prediction" subtitle="Machine Learning Classification Dashboard" />
        <EmptyState
          icon="📂"
          title="No dataset uploaded yet"
          description="Upload a customer CSV file on the Dataset page to get started with exploration, training, and prediction."
          action={
            <Link to="/dataset">
              <Button>Go to Dataset page</Button>
            </Link>
          }
        />
      </div>
    );
  }

  const lrF1 = results?.logistic_regression?.f1_score;
  const rfF1 = results?.random_forest?.f1_score;

  return (
    <div>
      <PageHeader title="Customer Care Prediction" subtitle="Machine Learning Classification Dashboard" />

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        <StatCard label="Dataset Records" value={datasetSummary.n_rows_after_cleaning.toLocaleString()} hint={`${datasetSummary.n_rows} raw rows`} />
        <StatCard label="Features" value={datasetSummary.feature_columns.length} hint={`${datasetSummary.numerical_columns.length} numeric · ${datasetSummary.categorical_columns.length} categorical`} />
        <StatCard label="Number of Classes" value={datasetSummary.n_classes ?? "—"} hint={`Target: ${datasetSummary.target_column}`} />
        <StatCard
          label="Logistic Regression F1"
          value={lrF1 !== undefined ? lrF1.toFixed(3) : "—"}
          hint={modelsTrained ? "on held-out test set" : "not trained yet"}
          accent="green"
        />
        <StatCard
          label="Random Forest F1"
          value={rfF1 !== undefined ? rfF1.toFixed(3) : "—"}
          hint={modelsTrained ? "on held-out test set" : "not trained yet"}
          accent="amber"
        />
      </div>

      {!modelsTrained && (
        <Card className="mt-6 flex flex-col items-center gap-3 border-brand-200 bg-brand-50 py-8 text-center">
          <p className="text-sm text-brand-800">
            Your dataset is loaded but models haven't been trained yet.
          </p>
          <Link to="/training">
            <Button>🚀 Go to Training</Button>
          </Link>
        </Card>
      )}

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <h2 className="mb-4 text-sm font-semibold text-slate-800">ML Workflow</h2>
          <WorkflowDiagram steps={WORKFLOW_STEPS} />
        </Card>

        <Card className="lg:col-span-2">
          <h2 className="mb-3 text-sm font-semibold text-slate-800">Project Description</h2>
          <p className="text-sm leading-relaxed text-slate-600">
            This application predicts <strong>{datasetSummary.target_column}</strong> for customers
            based on {datasetSummary.feature_columns.length} behavioral and demographic features from
            an uploaded dataset. Two classification models are trained and compared: a{" "}
            <strong>Logistic Regression</strong> model, which is fast and interpretable, and a{" "}
            <strong>Random Forest</strong> ensemble, which can capture more complex, non-linear patterns.
            Every number shown across this dashboard — accuracy, precision, recall, F1, confusion matrices,
            and feature importance — is computed directly from your uploaded CSV; nothing is hard-coded.
          </p>
          <p className="mt-3 text-sm leading-relaxed text-slate-600">
            Use the sidebar to explore the dataset, inspect exploratory analysis, train the models,
            compare their performance, view detailed evaluation metrics, and generate predictions for
            single customers or entire batches of new records.
          </p>
        </Card>
      </div>
    </div>
  );
}
