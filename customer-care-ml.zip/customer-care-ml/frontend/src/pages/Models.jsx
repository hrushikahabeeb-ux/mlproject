import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Badge, Button, Card, EmptyState, PageHeader, StatCard, Table } from "../components/UI";
import ConfusionMatrix from "../components/ConfusionMatrix";
import { useAppContext } from "../context/AppContext";

const TABS = [
  { key: "logistic_regression", label: "Logistic Regression" },
  { key: "random_forest", label: "Random Forest" },
];

export default function Models() {
  const { results, modelsTrained, refreshStatus } = useAppContext();
  const [activeTab, setActiveTab] = useState("logistic_regression");
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    refreshStatus().finally(() => setChecking(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (checking) return null;

  if (!modelsTrained || !results) {
    return (
      <div>
        <PageHeader title="Model Details" subtitle="Detailed evaluation for each model" />
        <EmptyState
          icon="🧠"
          title="Models not trained yet"
          description="Train both models on the Training page to see detailed evaluation."
          action={
            <Link to="/training">
              <Button>Go to Training</Button>
            </Link>
          }
        />
      </div>
    );
  }

  const model = results[activeTab];
  const reportRows = Object.entries(model.classification_report)
    .filter(([key]) => !["accuracy", "macro avg", "weighted avg"].includes(key))
    .map(([label, m]) => ({
      Class: label,
      Precision: m.precision.toFixed(3),
      Recall: m.recall.toFixed(3),
      "F1-Score": m["f1-score"].toFixed(3),
      Support: m.support,
    }));

  const overallRows = ["macro avg", "weighted avg"]
    .filter((k) => model.classification_report[k])
    .map((k) => {
      const m = model.classification_report[k];
      return {
        Class: k,
        Precision: m.precision.toFixed(3),
        Recall: m.recall.toFixed(3),
        "F1-Score": m["f1-score"].toFixed(3),
        Support: m.support,
      };
    });

  return (
    <div>
      <PageHeader title="Model Details" subtitle="Detailed evaluation for each model" />

      <div className="mb-6 flex gap-2 border-b border-slate-200">
        {TABS.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`border-b-2 px-4 py-2.5 text-sm font-medium transition-colors ${
              activeTab === tab.key
                ? "border-brand-600 text-brand-700"
                : "border-transparent text-slate-500 hover:text-slate-700"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <StatCard label="Accuracy" value={model.accuracy.toFixed(4)} />
        <StatCard label="Precision" value={model.precision.toFixed(4)} />
        <StatCard label="Recall" value={model.recall.toFixed(4)} />
        <StatCard label="F1 Score" value={model.f1_score.toFixed(4)} />
      </div>

      <div className="mb-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <h2 className="mb-3 text-sm font-semibold text-slate-800">Confusion Matrix</h2>
          <ConfusionMatrix matrix={model.confusion_matrix} labels={model.labels} />
        </Card>

        <Card>
          <h2 className="mb-3 text-sm font-semibold text-slate-800">Classification Report</h2>
          <Table columns={["Class", "Precision", "Recall", "F1-Score", "Support"]} rows={reportRows} />
          <div className="mt-3">
            <Table columns={["Class", "Precision", "Recall", "F1-Score", "Support"]} rows={overallRows} />
          </div>
        </Card>
      </div>

      {activeTab === "random_forest" && model.feature_importance && (
        <Card>
          <div className="mb-1 flex items-center gap-2">
            <h2 className="text-sm font-semibold text-slate-800">Top Feature Importance</h2>
            <Badge color="amber">Random Forest</Badge>
          </div>
          <p className="mb-4 text-xs text-slate-500">
            Feature importance indicates how useful features were to the trained model; it does not
            establish causation.
          </p>
          <ResponsiveContainer width="100%" height={Math.max(240, model.feature_importance.length * 32)}>
            <BarChart
              data={model.feature_importance.slice().reverse()}
              layout="vertical"
              margin={{ left: 40, right: 20 }}
            >
              <XAxis type="number" tick={{ fontSize: 11 }} />
              <YAxis type="category" dataKey="feature" tick={{ fontSize: 11 }} width={160} />
              <Tooltip formatter={(v) => v.toFixed(4)} />
              <Bar dataKey="importance" fill="#f5a623" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      )}
    </div>
  );
}
