import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Badge, Button, Card, EmptyState, ErrorBanner, PageHeader, Table, WorkflowDiagram } from "../components/UI";
import { useAppContext } from "../context/AppContext";
import { batchDownloadUrl, predictBatch } from "../services/api";

const WORKFLOW_STEPS = [
  "Upload New CSV",
  "Validate Columns",
  "Load Trained Model",
  "Preprocess",
  "Predict",
  "Add Prediction",
  "Download CSV",
];

export default function BatchPrediction() {
  const { modelsTrained, refreshStatus } = useAppContext();
  const [model, setModel] = useState("random_forest");
  const [file, setFile] = useState(null);
  const [dragOver, setDragOver] = useState(false);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    refreshStatus().finally(() => setChecking(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleFile = (f) => {
    if (!f) return;
    if (!f.name.toLowerCase().endsWith(".csv")) {
      setError("Please upload a .csv file.");
      return;
    }
    setError("");
    setFile(f);
    setResult(null);
  };

  const handleRun = async () => {
    if (!file) return;
    setRunning(true);
    setError("");
    setResult(null);
    try {
      const res = await predictBatch(file, model);
      setResult(res);
    } catch (e) {
      setError(e.message);
    } finally {
      setRunning(false);
    }
  };

  if (checking) return null;

  if (!modelsTrained) {
    return (
      <div>
        <PageHeader title="Batch Prediction" subtitle="Predict outcomes for many customers at once" />
        <EmptyState
          icon="📥"
          title="Models not trained yet"
          description="Train the models on the Training page before running batch predictions."
          action={
            <Link to="/training">
              <Button>Go to Training</Button>
            </Link>
          }
        />
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Batch Prediction" subtitle="Upload a CSV of new customers (no target column needed) to predict in bulk" />
      <ErrorBanner message={error} />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <h2 className="mb-4 text-center text-sm font-semibold text-slate-800">Workflow</h2>
          <WorkflowDiagram steps={WORKFLOW_STEPS} />
        </Card>

        <div className="space-y-6 lg:col-span-2">
          <Card
            className={`flex flex-col items-center justify-center gap-2 border-2 border-dashed py-10 text-center transition-colors ${
              dragOver ? "border-brand-500 bg-brand-50" : "border-slate-300"
            }`}
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              handleFile(e.dataTransfer.files?.[0]);
            }}
          >
            <span className="text-3xl">📥</span>
            <p className="text-sm font-semibold text-slate-800">
              {file ? file.name : "Upload New Customer CSV"}
            </p>
            <p className="text-xs text-slate-500">Drag & drop or browse — no target column required</p>
            <label>
              <input type="file" accept=".csv" className="hidden" onChange={(e) => handleFile(e.target.files?.[0])} />
              <span className="mt-1 inline-block cursor-pointer rounded-lg bg-slate-100 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-200">
                Browse Files
              </span>
            </label>
          </Card>

          <div className="flex flex-wrap items-center gap-4">
            <p className="text-sm font-semibold text-slate-800">Prediction Model:</p>
            {[
              { key: "logistic_regression", label: "Logistic Regression" },
              { key: "random_forest", label: "Random Forest" },
            ].map((opt) => (
              <label key={opt.key} className="flex cursor-pointer items-center gap-2 text-sm text-slate-700">
                <input
                  type="radio"
                  name="batch-model"
                  checked={model === opt.key}
                  onChange={() => setModel(opt.key)}
                  className="h-4 w-4 accent-brand-600"
                />
                {opt.label}
              </label>
            ))}
            <Button onClick={handleRun} disabled={!file || running} className="ml-auto">
              {running ? "Running predictions..." : "Run Batch Prediction"}
            </Button>
          </div>

          {result && (
            <Card>
              <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-3">
                  <Badge color="green">{result.n_records} records</Badge>
                  <Badge color="blue">Model: {result.model_used === "random_forest" ? "Random Forest" : "Logistic Regression"}</Badge>
                  <Badge color="slate">Prediction status: complete</Badge>
                </div>
                <a href={batchDownloadUrl} download="customer_predictions.csv">
                  <Button variant="secondary">⬇ Download Predictions CSV</Button>
                </a>
              </div>
              <p className="mb-2 text-xs text-slate-500">Preview of first {result.preview.length} predictions</p>
              <Table columns={result.columns} rows={result.preview} />
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
