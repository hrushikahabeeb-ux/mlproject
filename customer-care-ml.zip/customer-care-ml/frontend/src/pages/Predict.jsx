import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Button, Card, EmptyState, ErrorBanner, LoadingSpinner, PageHeader } from "../components/UI";
import { useAppContext } from "../context/AppContext";
import { getSchema, predictSingle } from "../services/api";

export default function Predict() {
  const { modelsTrained, refreshStatus } = useAppContext();
  const [schema, setSchema] = useState(null);
  const [formValues, setFormValues] = useState({});
  const [model, setModel] = useState("random_forest");
  const [loading, setLoading] = useState(true);
  const [predicting, setPredicting] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    refreshStatus().finally(() => setChecking(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!checking && modelsTrained) {
      setLoading(true);
      getSchema()
        .then((s) => {
          setSchema(s);
          const initial = {};
          s.fields.forEach((f) => {
            if (f.type === "numerical") initial[f.name] = Math.round(f.default * 100) / 100;
            else if (f.type === "categorical") initial[f.name] = f.options[0];
            else if (f.type === "boolean") initial[f.name] = false;
          });
          setFormValues(initial);
        })
        .catch((e) => setError(e.message))
        .finally(() => setLoading(false));
    }
  }, [checking, modelsTrained]);

  const handleChange = (name, value) => {
    setFormValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setPredicting(true);
    setError("");
    setResult(null);
    try {
      const res = await predictSingle(model, formValues);
      setResult(res);
    } catch (e) {
      setError(e.message);
    } finally {
      setPredicting(false);
    }
  };

  if (checking) return null;

  if (!modelsTrained) {
    return (
      <div>
        <PageHeader title="Customer Prediction" subtitle="Predict the outcome for a single customer" />
        <EmptyState
          icon="🎯"
          title="Models not trained yet"
          description="Train the models on the Training page before making predictions."
          action={
            <Link to="/training">
              <Button>Go to Training</Button>
            </Link>
          }
        />
      </div>
    );
  }

  if (loading) return <LoadingSpinner label="Loading form..." />;

  if (!schema) {
    return (
      <div>
        <PageHeader title="Customer Prediction" subtitle="Predict the outcome for a single customer" />
        <ErrorBanner message={error || "Could not load the prediction form."} />
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Customer Prediction" subtitle="Predict the outcome for a single customer" />
      <ErrorBanner message={error} />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              {schema.fields.map((field) => (
                <FieldInput
                  key={field.name}
                  field={field}
                  value={formValues[field.name]}
                  onChange={(v) => handleChange(field.name, v)}
                />
              ))}
            </div>

            <div className="border-t border-slate-200 pt-4">
              <p className="mb-2 text-sm font-semibold text-slate-800">Prediction Model</p>
              <div className="flex gap-4">
                {[
                  { key: "logistic_regression", label: "Logistic Regression" },
                  { key: "random_forest", label: "Random Forest" },
                ].map((opt) => (
                  <label key={opt.key} className="flex cursor-pointer items-center gap-2 text-sm text-slate-700">
                    <input
                      type="radio"
                      name="model"
                      checked={model === opt.key}
                      onChange={() => setModel(opt.key)}
                      className="h-4 w-4 accent-brand-600"
                    />
                    {opt.label}
                  </label>
                ))}
              </div>
            </div>

            <Button type="submit" disabled={predicting} className="w-full sm:w-auto">
              {predicting ? "Predicting..." : "Predict Customer"}
            </Button>
          </form>
        </Card>

        <div>
          {result ? (
            <Card>
              <h2 className="mb-4 text-sm font-semibold text-slate-800">Prediction Result</h2>
              <p className="text-xs uppercase tracking-wide text-slate-500">Predicted Class</p>
              <p className="mb-4 text-3xl font-bold text-brand-600">{result.predicted_class}</p>

              {result.probabilities && (
                <>
                  <p className="mb-2 text-xs uppercase tracking-wide text-slate-500">Class Probabilities</p>
                  <div className="space-y-2">
                    {Object.entries(result.probabilities)
                      .sort((a, b) => b[1] - a[1])
                      .map(([cls, prob]) => (
                        <div key={cls}>
                          <div className="mb-0.5 flex justify-between text-xs text-slate-600">
                            <span>Class {cls}</span>
                            <span>{(prob * 100).toFixed(1)}%</span>
                          </div>
                          <div className="h-2 w-full rounded-full bg-slate-100">
                            <div
                              className="h-2 rounded-full bg-brand-500"
                              style={{ width: `${prob * 100}%` }}
                            />
                          </div>
                        </div>
                      ))}
                  </div>
                </>
              )}
            </Card>
          ) : (
            <Card className="flex flex-col items-center justify-center gap-2 py-12 text-center text-slate-400">
              <span className="text-3xl">🎯</span>
              <p className="text-sm">Fill the form and click Predict Customer to see a result here.</p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

function FieldInput({ field, value, onChange }) {
  if (field.type === "categorical") {
    return (
      <label className="block">
        <span className="mb-1 block text-xs font-medium text-slate-600">{field.name}</span>
        <select
          value={value ?? ""}
          onChange={(e) => onChange(e.target.value)}
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
        >
          {field.options.map((opt) => (
            <option key={opt} value={opt}>
              {opt}
            </option>
          ))}
        </select>
      </label>
    );
  }

  if (field.type === "boolean") {
    return (
      <label className="flex items-center gap-2 pt-5 text-sm text-slate-700">
        <input
          type="checkbox"
          checked={!!value}
          onChange={(e) => onChange(e.target.checked)}
          className="h-4 w-4 accent-brand-600"
        />
        {field.name}
      </label>
    );
  }

  return (
    <label className="block">
      <span className="mb-1 block text-xs font-medium text-slate-600">
        {field.name}
        <span className="ml-1 text-slate-400">
          ({field.min}–{field.max})
        </span>
      </span>
      <input
        type="number"
        step="any"
        value={value ?? ""}
        onChange={(e) => onChange(e.target.value === "" ? "" : Number(e.target.value))}
        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
      />
    </label>
  );
}
