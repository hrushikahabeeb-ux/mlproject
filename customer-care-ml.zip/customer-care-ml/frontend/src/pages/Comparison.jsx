import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Button, Card, EmptyState, PageHeader, Table } from "../components/UI";
import { useAppContext } from "../context/AppContext";

export default function Comparison() {
  const { results, modelsTrained, refreshStatus, datasetSummary } = useAppContext();
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    refreshStatus().finally(() => setChecking(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (checking) return null;

  if (!modelsTrained || !results) {
    return (
      <div>
        <PageHeader title="Model Comparison" subtitle="Compare Logistic Regression and Random Forest performance" />
        <EmptyState
          icon="⚖️"
          title="Models not trained yet"
          description="Train both models on the Training page to see a side-by-side comparison."
          action={
            <Link to="/training">
              <Button>Go to Training</Button>
            </Link>
          }
        />
      </div>
    );
  }

  const lr = results.logistic_regression;
  const rf = results.random_forest;

  const tableRows = [
    {
      Model: "Logistic Regression",
      Accuracy: lr.accuracy.toFixed(4),
      Precision: lr.precision.toFixed(4),
      Recall: lr.recall.toFixed(4),
      "F1 Score": lr.f1_score.toFixed(4),
    },
    {
      Model: "Random Forest",
      Accuracy: rf.accuracy.toFixed(4),
      Precision: rf.precision.toFixed(4),
      Recall: rf.recall.toFixed(4),
      "F1 Score": rf.f1_score.toFixed(4),
    },
  ];

  const chartData = [
    { metric: "Accuracy", "Logistic Regression": lr.accuracy, "Random Forest": rf.accuracy },
    { metric: "Precision", "Logistic Regression": lr.precision, "Random Forest": rf.precision },
    { metric: "Recall", "Logistic Regression": lr.recall, "Random Forest": rf.recall },
    { metric: "F1 Score", "Logistic Regression": lr.f1_score, "Random Forest": rf.f1_score },
  ];

  const classCounts = Object.values(datasetSummary?.class_distribution || {});
  const isImbalanced =
    classCounts.length >= 2 && Math.min(...classCounts) / Math.max(...classCounts) < 0.7;

  return (
    <div>
      <PageHeader title="Model Comparison" subtitle="Compare Logistic Regression and Random Forest performance" />

      <Card className="mb-6">
        <h2 className="mb-3 text-sm font-semibold text-slate-800">Metrics Table</h2>
        <Table columns={["Model", "Accuracy", "Precision", "Recall", "F1 Score"]} rows={tableRows} />
      </Card>

      <Card className="mb-6">
        <h2 className="mb-4 text-sm font-semibold text-slate-800">Metric Comparison</h2>
        <ResponsiveContainer width="100%" height={320}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#eef1f6" />
            <XAxis dataKey="metric" tick={{ fontSize: 12 }} />
            <YAxis domain={[0, 1]} tick={{ fontSize: 12 }} />
            <Tooltip />
            <Legend />
            <Bar dataKey="Logistic Regression" fill="#3568f5" radius={[6, 6, 0, 0]} />
            <Bar dataKey="Random Forest" fill="#f5a623" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      <Card className="border-amber-200 bg-amber-50">
        <h2 className="mb-2 text-sm font-semibold text-amber-900">
          {isImbalanced ? "Why not just look at accuracy?" : "About these metrics"}
        </h2>
        <p className="text-sm leading-relaxed text-amber-800">
          {isImbalanced
            ? "This dataset's classes are imbalanced. A model can achieve high accuracy simply by favoring the majority class, while performing poorly on the minority class. Precision, recall, and F1 score reveal this: precision measures how many predicted-positive cases were actually positive, recall measures how many actual positives were correctly identified, and F1 is their harmonic mean. Relying on accuracy alone here would be misleading."
            : "This dataset's classes are fairly balanced, so accuracy is a reasonable headline number. Even so, precision, recall, and F1 score are shown because they reveal how well each model handles each class individually, not just overall correctness — which matters most in a customer-care context where both false positives and false negatives carry real costs."}
        </p>
      </Card>
    </div>
  );
}
