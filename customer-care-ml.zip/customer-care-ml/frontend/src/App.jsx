import { Navigate, Route, Routes } from "react-router-dom";
import Layout from "./components/Layout";
import { AppProvider } from "./context/AppContext";

import Dashboard from "./pages/Dashboard";
import Dataset from "./pages/Dataset";
import Analysis from "./pages/Analysis";
import Training from "./pages/Training";
import Comparison from "./pages/Comparison";
import Models from "./pages/Models";
import Predict from "./pages/Predict";
import BatchPrediction from "./pages/BatchPrediction";
import About from "./pages/About";

export default function App() {
  return (
    <AppProvider>
      <Layout>
        <Routes>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/dataset" element={<Dataset />} />
          <Route path="/analysis" element={<Analysis />} />
          <Route path="/training" element={<Training />} />
          <Route path="/comparison" element={<Comparison />} />
          <Route path="/models" element={<Models />} />
          <Route path="/predict" element={<Predict />} />
          <Route path="/batch-prediction" element={<BatchPrediction />} />
          <Route path="/about" element={<About />} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </Layout>
    </AppProvider>
  );
}
