import { createContext, useCallback, useContext, useState } from "react";
import { getDatasetSummary, getResults } from "../services/api";

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [datasetSummary, setDatasetSummary] = useState(null);
  const [results, setResults] = useState(null);
  const [trainedAt, setTrainedAt] = useState(null);
  const [datasetLoaded, setDatasetLoaded] = useState(false);
  const [modelsTrained, setModelsTrained] = useState(false);

  // Called on app load / after navigation to re-sync with backend state
  // (in case the backend already has a dataset/model loaded, e.g. after
  // a page refresh).
  const refreshStatus = useCallback(async () => {
    try {
      const summary = await getDatasetSummary();
      setDatasetSummary(summary);
      setDatasetLoaded(true);
    } catch {
      setDatasetLoaded(false);
      setDatasetSummary(null);
    }
    try {
      const res = await getResults();
      setResults(res.results);
      setTrainedAt(res.trained_at);
      setModelsTrained(true);
    } catch {
      setModelsTrained(false);
      setResults(null);
    }
  }, []);

  const value = {
    datasetSummary,
    setDatasetSummary,
    results,
    setResults,
    trainedAt,
    setTrainedAt,
    datasetLoaded,
    setDatasetLoaded,
    modelsTrained,
    setModelsTrained,
    refreshStatus,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useAppContext() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useAppContext must be used within AppProvider");
  return ctx;
}
