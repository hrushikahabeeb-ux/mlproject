// Simple correlation heatmap rendered as a CSS grid (no extra chart lib
// needed for this — it's a straightforward NxN colored grid with labels).
import { Fragment } from "react";

function colorForValue(v) {
  // v in [-1, 1]. Blue for negative, red for positive, white near 0.
  const clamped = Math.max(-1, Math.min(1, v));
  if (clamped >= 0) {
    const intensity = Math.round(clamped * 255);
    return `rgb(${255 - intensity}, ${255 - Math.round(intensity * 0.3)}, ${255 - intensity})`;
  }
  const intensity = Math.round(-clamped * 255);
  return `rgb(${255 - Math.round(intensity * 0.3)}, ${255 - intensity}, ${255})`;
}

export default function Heatmap({ columns, matrix }) {
  const cellSize = columns.length > 10 ? 44 : 56;

  return (
    <div className="overflow-x-auto">
      <div
        className="inline-grid gap-0.5"
        style={{
          gridTemplateColumns: `120px repeat(${columns.length}, ${cellSize}px)`,
        }}
      >
        <div />
        {columns.map((col) => (
          <div
            key={`h-${col}`}
            className="flex items-end justify-center pb-1 text-[10px] font-medium text-slate-500"
            style={{ writingMode: "vertical-rl", height: 90 }}
          >
            {col}
          </div>
        ))}

        {columns.map((rowLabel, i) => (
          <Fragment key={`row-${rowLabel}`}>
            <div
              className="flex items-center justify-end pr-2 text-[11px] font-medium text-slate-600"
              style={{ height: cellSize }}
            >
              {rowLabel}
            </div>
            {matrix[i].map((value, j) => (
              <div
                key={`c-${i}-${j}`}
                className="flex items-center justify-center text-[10px] font-medium text-slate-700"
                style={{ height: cellSize, backgroundColor: colorForValue(value) }}
                title={`${rowLabel} vs ${columns[j]}: ${value}`}
              >
                {value.toFixed(2)}
              </div>
            ))}
          </Fragment>
        ))}
      </div>
    </div>
  );
}
