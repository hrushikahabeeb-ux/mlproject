export default function ConfusionMatrix({ matrix, labels }) {
  const max = Math.max(...matrix.flat());

  return (
    <div className="inline-block">
      <div className="flex">
        <div style={{ width: 110 }} />
        <div className="flex-1 text-center text-xs font-semibold text-slate-500">Predicted</div>
      </div>
      <div className="flex">
        <div style={{ width: 110 }} />
        {labels.map((l) => (
          <div key={l} className="w-20 text-center text-xs font-medium text-slate-500">
            {l}
          </div>
        ))}
      </div>
      {matrix.map((row, i) => (
        <div key={i} className="flex items-stretch">
          {i === 0 && (
            <div
              className="flex items-center justify-center text-xs font-semibold text-slate-500"
              style={{ width: 24, writingMode: "vertical-rl", transform: "rotate(180deg)" }}
            >
              Actual
            </div>
          )}
          {i !== 0 && <div style={{ width: 24 }} />}
          <div className="flex w-20 items-center justify-end pr-2 text-xs font-medium text-slate-500">{labels[i]}</div>
          {row.map((value, j) => {
            const intensity = max ? value / max : 0;
            const isDiagonal = i === j;
            return (
              <div
                key={j}
                className="flex h-20 w-20 items-center justify-center border border-white text-sm font-bold"
                style={{
                  backgroundColor: isDiagonal
                    ? `rgba(16, 185, 129, ${0.15 + intensity * 0.6})`
                    : `rgba(239, 68, 68, ${0.1 + intensity * 0.5})`,
                  color: isDiagonal ? "#065f46" : "#7f1d1d",
                }}
              >
                {value}
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}
