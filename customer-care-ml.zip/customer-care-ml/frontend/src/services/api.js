import axios from "axios";

const api = axios.create({
  baseURL: "/api",
});

// Normalizes error handling so pages can just read err.message.
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const detail = error?.response?.data?.detail;
    const message = detail || error.message || "Something went wrong.";
    return Promise.reject(new Error(message));
  }
);

export const uploadDataset = (file, targetColumn) => {
  const formData = new FormData();
  formData.append("file", file);
  if (targetColumn) formData.append("target_column", targetColumn);
  return api.post("/upload", formData, {
    headers: { "Content-Type": "multipart/form-data" },
  }).then((r) => r.data);
};

export const getDatasetSummary = () => api.get("/dataset/summary").then((r) => r.data);

export const getDatasetPreview = (rows = 15) =>
  api.get(`/dataset/preview?rows=${rows}`).then((r) => r.data);

export const getAnalysis = () => api.get("/analysis").then((r) => r.data);

export const trainModels = () => api.post("/train").then((r) => r.data);

export const getResults = () => api.get("/results").then((r) => r.data);

export const getFeatureImportance = () => api.get("/feature-importance").then((r) => r.data);

export const getSchema = () => api.get("/schema").then((r) => r.data);

export const predictSingle = (model, record) =>
  api.post("/predict", { model, record }).then((r) => r.data);

export const predictBatch = (file, model) => {
  const formData = new FormData();
  formData.append("file", file);
  formData.append("model", model);
  return api.post("/predict/batch", formData, {
    headers: { "Content-Type": "multipart/form-data" },
  }).then((r) => r.data);
};

export const batchDownloadUrl = "/api/predict/batch/download";

export default api;
